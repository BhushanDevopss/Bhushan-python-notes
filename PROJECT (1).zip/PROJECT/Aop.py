#Aop.py----File Name----Module Name
def  sumop(a,b):
    print("Sum({},{})={}".format(a,b,a+b))
def  subop(a,b):
    print("Sub({},{})={}".format(a,b,a-b))
def  mulop(a,b):
    print("Mul({},{})={}".format(a,b,a*b))

