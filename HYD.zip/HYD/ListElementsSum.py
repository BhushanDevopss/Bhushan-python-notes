#Program for obtaining sum of all number of given list
#ListElementsSum.py-----File Name and Module Name
def  listdigitssum():
	print("Enter List of Values separated by space:")
	lst=[int(val) for val in input().split()]
	sumlist=[]
	for val in lst:
		sval=str(val)
		s=0
		for dig in sval:
			s=s+int(dig)
		else:
			sumlist.append(s)
	else:
		print("Given Input List:{}".format(lst))
		print("Sum  List:{}".format(sumlist))

		


	
	
